#Set the initial capacity of the hashing table
#Make this available to other classes and Python code for this project
def initialize():
    global hashTableSize
    hashTableSize = 11 #A prime number for initial capacity